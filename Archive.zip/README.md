# fashionLanding
landing for inst

# Entry point
https://flipmotion.github.io/fashionLanding/
[link to Landing](https://flipmotion.github.io/fashionLanding/index.html)