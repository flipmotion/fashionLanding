/**
 * @author Alex Rache <grumblerbear@gmail.com>
 * @since 18.08.2016 15:31
 * @project test2.3x30.ru
 */
console.log('init');