$(window).ready(function () {
    $('#js-show-form2').click(function () {
        $('#js-form2').show();
        return false;
    });
    $('#js-close-form2').click(function () {
        $('#js-form2').hide();
        return false;
    });
});